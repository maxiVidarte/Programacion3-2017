<?php
include_once "./Clases/Persona.php";
class Policia
{
    public function __construct(){
        
    }
}

?>