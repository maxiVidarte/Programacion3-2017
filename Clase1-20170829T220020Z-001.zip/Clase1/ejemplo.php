<?php 
//PRIMER EJEMPLO PARA LEVANTAR PHP EN UN SERVIDOR
/*$vec = array(1,2,3,4);
var_dump($vec);*/

?>